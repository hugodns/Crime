-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  sam. 05 mai 2018 à 14:07
-- Version du serveur :  5.6.38
-- Version de PHP :  7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `DMR`
--

-- --------------------------------------------------------

--
-- Structure de la table `amitie`
--

CREATE TABLE `amitie` (
  `ID1` int(11) NOT NULL,
  `ID2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `amitie`
--

INSERT INTO `amitie` (`ID1`, `ID2`) VALUES
(1, 2),
(1, 3),
(2, 3);

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `Mail` text NOT NULL,
  `Pseudo` text NOT NULL,
  `Mdp` text NOT NULL,
  `Nom` text NOT NULL,
  `Prenom` text NOT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`Mail`, `Pseudo`, `Mdp`, `Nom`, `Prenom`, `ID`) VALUES
('adrien.mina@edu.ece.fr', 'Adrien', 'mdp', 'Mina', 'Adrien', 1),
('clement.robin@edu.ece.fr', 'Clem', 'mdp', 'Robin', 'Clement', 2),
('hugo.denis@edu.ece.fr', 'Hugo', 'mdp', 'Denis', 'Hugo', 3),
('test@edu.ece.fr', 'test', 'mdp', 'Test', 'Test', 4);

-- --------------------------------------------------------

--
-- Structure de la table `Post`
--

CREATE TABLE `Post` (
  `Date` date NOT NULL,
  `Contenu` text NOT NULL,
  `ID` int(11) NOT NULL,
  `ID_auteur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Post`
--

INSERT INTO `Post` (`Date`, `Contenu`, `ID`, `ID_auteur`) VALUES
('2018-01-01', 'Mon premier post', 1, 2),
('2018-01-01', 'Il fait trop beau', 2, 3);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
