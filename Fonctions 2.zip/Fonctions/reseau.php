<!DOCTYPE html>
<html>
    <head>
         
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="style.css">
	   <title> Reseau </title>
    </head>
	
	<body>
	
	
		<form NAME ="formulaire" METHOD ="POST" ACTION = "reseaut.php">
		

            <label> ID </label> <INPUT TYPE ="Number" Name = "ID">
            <label> Nom de client </label>  <INPUT TYPE ="TEXT" Name = "nom" id="nom"> 
            <label> Prenom </label> <INPUT TYPE ="TEXT" Name = "prenom" id="prenom"> 
            <INPUT TYPE ="Submit" Name = "Submit1" VALUE="Soumettre">
		</form>
	</body>
</html> 
