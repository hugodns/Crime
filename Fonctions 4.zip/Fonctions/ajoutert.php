
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main-style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<style>
body {
    background-color:#00AFFF;
}
</style>


    <script type="text/javascript"  >


        var id= "<?php Print($ID); ?>";
        var email= "<?php Print($email); ?>";
        var username= "<?php Print($username); ?>";
        var name= "<?php Print($name); ?>";



        window.onload = function() {

            alert(name + fname);
            document.getElementById("completeName").innerHTML = fname + " " + name;
            document.getElementById("details").innerHTML = "User: " + username + "   Mail: " + email;
        }
        alert(name + fname);

    </script>

</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="index.html">
            </a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="feed.php">Feed</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="jobs.html">Jobs</a></li>
            <li class="active"><a href="reseaut.php">Network</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
            <li><a href="connexion.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
        </ul>

    </div>
</nav>


        
        
    </div>
</div>

<div class="container">
  <div class="row">
      <div class="col-md-12 text-center ">
          <div class="panel panel-default">
              <div class="userprofile social ">
                  <h3 class="username"><label type="text" id="completeName" name="completeName" ></h3>
                  <label type="text" id="details" name="details" >
<?php
    define('DB_SERVER','localhost');
    define('DB_USER','root');
    define('DB_PASS','');
    $database='DMR';
    $db_handle=mysqli_connect(DB_SERVER,DB_USER,DB_PASS);
    $db_found=mysqli_select_db($db_handle,$database);
session_start();
$ID =  $_SESSION['id'];
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
 echo "RECHERCHE D'AMIS <br><br><br>";

    if($db_found){

        
      $sql2="SELECT * FROM clients WHERE Nom='$nom' AND Prenom='$prenom'";
        
       $result2=mysqli_query($db_handle,$sql2);  
        

        while ($data = mysqli_fetch_assoc($result2)) {
            $ida=$data['ID'];
            $_SESSION['ida']=$ida;
        echo '<div class="userpic"> <img src="photo'.$ida.'.jpg" alt=""class="userpicimg" height="50" width="50"> </div>';
        echo $data['Prenom'];
        echo " ";
        echo $data['Nom']. "<br>";
        echo '<a href="ajout.php">Ajouter</a>';
            
            
            
            
        }
    }
?>
