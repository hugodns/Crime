

<?php
    define('DB_SERVER','localhost');
    define('DB_USER','root');
    define('DB_PASS','');
    $database='DMR';
    $db_handle=mysqli_connect(DB_SERVER,DB_USER,DB_PASS);
    $db_found=mysqli_select_db($db_handle,$database);
session_start();
$ID =  $_SESSION['id'];


    if($db_found){

        
        $sql="SELECT*FROM Post";
        
        $result=mysqli_query($db_handle,$sql);  

        while ($data = mysqli_fetch_assoc($result)) {
        echo $data['Date']. "<br>";
        echo $data['Contenu']. "<br><br>";
        header('Location: profile.php');
        
  //      echo " est ami avec ID2: " . $data['ID2'] . '<br>';
        }
               }
?>
        