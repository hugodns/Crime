<!DOCTYPE html>
<head>
    <title>Feed</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main-style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


<style>
body {
    background-color:#00AFFF;
}
</style>
    <script type="text/javascript"  >


        var id= "<?php Print($ID); ?>";
        var email= "<?php Print($email); ?>";
        var username= "<?php Print($username); ?>";
        var name= "<?php Print($name); ?>";



        window.onload = function() {

            alert(name + fname);
            document.getElementById("completeName").innerHTML = fname + " " + name;
            document.getElementById("details").innerHTML = "User: " + username + "   Mail: " + email;
        }
        alert(name + fname);

    </script>

</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="index.html">
            </a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="feed.php">Feed</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="jobs.html">Jobs</a></li>
            <li><a href="reseaut.php">Network</a></li>
        </ul>

        <ul class="nav navbar-nav navbar-right">
            <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
            <li><a href="connexion.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
        </ul>

    </div>
</nav>
<div class="container">
  <div class="row">
      <div class="col-md-12 text-center ">
          <div class="panel panel-default">
              <div class="userprofile social ">
                  <h3 class="username"><label type="text" id="completeName" name="completeName" ></h3>
                  <label type="text" id="details" name="details" >
      <?php
    define('DB_SERVER','localhost');
    define('DB_USER','root');
    define('DB_PASS','');
    $database='DMR';
    $db_handle=mysqli_connect(DB_SERVER,DB_USER,DB_PASS);
    $db_found=mysqli_select_db($db_handle,$database);
session_start();
$ID =  $_SESSION['id'];
 echo "FIL D'ACTUALITE <br><br><br>";

    if($db_found){

        
        
      $sql2="SELECT ID2 FROM amitie WHERE ID1= $ID";
        
       $result2=mysqli_query($db_handle,$sql2);  
        

        while ($data = mysqli_fetch_assoc($result2)) {
            $ida=$data['ID2'];
            
            
            
            
        $sql4="SELECT * FROM Post WHERE ID_auteur =$ida";                   
            $result4=mysqli_query($db_handle,$sql4);  

        while ($data2 = mysqli_fetch_assoc($result4)) { 
            $sql3="SELECT * FROM clients WHERE ID =$ida";                   
            $result3=mysqli_query($db_handle,$sql3);  
            
        while ($data4 = mysqli_fetch_assoc($result3)) { 
            echo '<div class="userpic"> <img src="photo'.$ida.'.jpg" alt=""class="userpicimg" height="50" width="50"> </div>';
         echo $data4['Prenom'];
            echo " ";
        echo $data4['Nom']. "<br>";      
        echo $data2['Contenu']. "<br>";
            echo '<a href="#">Liker</a>';
            echo" ";
            echo '<a href="#">Commenter</a>';
            echo "<br><br>";
        
             }
        }
        }
    
       $sql5="SELECT ID1 FROM amitie WHERE ID2= $ID";
        
       $result5=mysqli_query($db_handle,$sql5);  
        

        while ($data5 = mysqli_fetch_assoc($result5)) {
            $ida=$data5['ID1'];
            
            
        $sql6="SELECT * FROM Post WHERE ID_auteur =$ida";                   
            $result6=mysqli_query($db_handle,$sql6);  

        while ($data6 = mysqli_fetch_assoc($result6)) { 
            $sql7="SELECT * FROM clients WHERE ID =$ida";                   
            $result7=mysqli_query($db_handle,$sql7);  
            
        while ($data7 = mysqli_fetch_assoc($result7)) { 
            echo '<div class="userpic"> <img src="photo'.$ida.'.jpg" alt=""class="userpicimg" height="50" width="50"> </div>';
         echo $data7['Prenom'];
            echo " ";
        echo $data7['Nom']. "<br>";      
        echo $data6['Contenu']. "<br><br>";
        
             }
        }
        }
    }
?>
