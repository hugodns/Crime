    <?php
    define('DB_SERVER','localhost');
    define('DB_USER','root');
    define('DB_PASS','');
    $database='DMR';
    $db_handle=mysqli_connect(DB_SERVER,DB_USER,DB_PASS);
    $db_found=mysqli_select_db($db_handle,$database);
session_start();
$ID =  $_SESSION['id'];
$ida = $_SESSION['ida'];

    if($db_found){
$sql="SELECT * FROM amitie WHERE ID1=$ID AND ID2=$ida";
        
       $result=mysqli_query($db_handle,$sql);  
        
    $count1 = mysqli_num_rows($result);
 
if($count1 == 0) {
    
$sql3="SELECT * FROM amitie WHERE ID1=$ida AND ID2=$ID";
        
       $result3=mysqli_query($db_handle,$sql3);  
        
    $count3 = mysqli_num_rows($result3);
    
    if($count3 == 0) {
        
      $sql2="INSERT INTO amitie (ID1, ID2) VALUES ('$ID','$ida')";
        
       $result2=mysqli_query($db_handle,$sql2);  
        
            
            
            header('Location: reseaut.php');
            
        }
    else header('Location: reseaut.php');
    }
        else header('Location: reseaut.php');
    }
?>
